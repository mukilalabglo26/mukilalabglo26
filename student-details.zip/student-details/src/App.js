import logo from './logo.svg';
import './App.css';
import Myfunction from './student';
import { useState } from 'react';

function App() {
  // const [details,setDetails]=useState({
  //   name:'',
  //   email:'',
  //   profession:''

  // })
  
  // function handleSubmit(e) {
  //   e.preventDefault()
  //   console.log(details);
  //   // // if(name===" "){
  //   //   console.log(name)

  //   // // }
  // }
  // return(
  //   <div>
  //     <form onSubmit={handleSubmit}>
  //     <input type="text" name="name" placeholder='name' onChange={(e) => {setDetails({...details, [e.target.name]: e.target.value})}} />
  //     <input type="text" name="email" placeholder='email' onChange={(e) => {setDetails({...details, [e.target.name]: e.target.value})}} />
  //     <input type="text" name="profession" placeholder='profession' onChange={(e) => {setDetails({...details, [e.target.name]: e.target.value})}} />
  //     <button onClick={handleSubmit}>submit</button>
  //     </form>
  //   </div>
  // )
  const student_details = {
    name: "mukila",
    id: "1234",
    roll_no: "11",
    email: "muki@gmail.com"
  }
  return (
    <>
      <Myfunction student={student_details} />
    </>

  );
}

export default App;
