import React from "react"

function Myfunction(props) {
    // console.log(props.student);
    function details() {
        console.log(props.student.name);
        console.log(props.student.id);

        console.log(props.student.roll_no);
        console.log(props.student.email);
    }
    return (
        <>

            <ul>
                <li>{props.student.name}</li>
                <li>{props.student.id}</li>
                <li>{props.student.roll_no}</li>
                <li>{props.student.email}</li>
            <button onClick={() => details()}>click</button>
            </ul>


        </>
    )

}

export default Myfunction;