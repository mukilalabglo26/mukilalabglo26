import logo from './logo.svg';
import './App.css';

import Table from './table';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';

import Userdetails from './user_details';

function App() {

  return (

    <Router>
      <Routes>
        <Route path='/' element={<Userdetails />} />
        <Route path='/table/:id' element={<Table />} />
      </Routes>

    </Router>






  );
}

export default App;
