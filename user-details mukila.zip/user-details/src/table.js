import React from "react";
import { useParams } from "react-router-dom";

function Table() {
    const { id } = useParams()
    console.log("id", id);
    const details = [{
        name: "mukila",
        id: "1234",
        email: "muki@gmail.com"
    },
    {
        name: "prema",
        id: "1567",
        email: "prema@gmail.com"
    },
    {
        name: "kishore",
        id: "1745",
        email: "kishore@gmail.com"
    }];
    return (
        <>
            {
                details.filter((el) => el.id === (id)).map((ele) =>
                    // console.log('name ', ele.name)
                    <>

                        <p>name:{ele.name}</p><br />
                        <p>id:{ele.id}</p><br />
                        <p>email:{ele.email}</p><br />
                    </>
                )}

        </>

    )

}
export default Table;