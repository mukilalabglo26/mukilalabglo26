import React from "react";
import { Link, useNavigate } from "react-router-dom";

function Userdetails() {
  const navigate = useNavigate()
  const details = [{
    name: "mukila",
    id: "1234",
    email: "muki@gmail.com"
  },
  {
    name: "prema",
    id: "1567",
    email: "prema@gmail.com"
  },
  {
    name: "kishore",
    id: "1745",
    email: "kishore@gmail.com"
  }];
  const arr = ["Name", "Id", "Email"];
  function navigateTable(name) {
    navigate(`/table/${name}`)
  }
  return (
    <>
      <table border={2}>
        {arr.map((el) => <th>{el}</th>)}
        {details.map((el) => {
          return (
            <tr>
              <td><button onClick={() => navigateTable(el.id)}>{el.name}</button></td>
              <td>{el.id}</td>
              <td>{el.email}</td>
            </tr>
          )
        })}
      </table>
    </>
  )
}
export default Userdetails;