import logo from './logo.svg';
import './App.css';
import React, { useState } from 'react';

function App() {


  const [details, setDetails] = useState({
    Name: '',
    email: '',
    profession: ''

  })
  const [list, setList] = useState([]);
  function handleSubmit(e) {
    e.preventDefault()
    console.log(details);
    if (details) {
      setList((el) => [...el, details])
      // setList(true);
      setDetails(" ");
    }


    // setDetails((el)=>[...el,details])

    // }
    // else{
    // setList("wrong");
    // }
  }
  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input type="text" name="Name" placeholder='name' onChange={(e) => { setDetails({ ...details, [e.target.name]: e.target.value }) }} />
        <input type="text" name="email" placeholder='email' onChange={(e) => { setDetails({ ...details, [e.target.name]: e.target.value }) }} />
        <input type="text" name="profession" placeholder='profession' onChange={(e) => { setDetails({ ...details, [e.target.name]: e.target.value }) }} />
        <button onClick={handleSubmit}>submit</button>
      </form>
      {/* { list ? <>  */}
      {/* <h4>{details.Name}</h4> */}
      {/* <h4>{details.email}</h4> */}
      {/* <h4>{details.profession}</h4> */}
      {/* </>:<></> */}


      {/* } */}

      {/* <p>{details.name}</p> */}
      {/* <p>{details.email}</p> */}
      {/* <p>{details.profession}</p> */}

      {list.map((a) => <div>
        <li>{a.Name}</li>
        <li>{a.email}</li>
        <li>{a.profession}</li>
      </div>)}
    </div>
  )



}

export default App;
